# Danfo Chronicles — Godot Project Skeleton

This is a **skeleton**, not a finished importable project — I can't run Godot in my
environment to test-export a `.tscn` scene file, so instead of handing you a scene
file that might have subtle syntax errors, this gives you working scripts plus
exact instructions for the node tree to build in the editor (takes ~5 minutes).

## 1. Create the project
Open Godot 4.x → New Project → point it at this folder (it already has `project.godot`).

## 2. Build the scene tree
Create `scenes/Main.tscn` with this node structure (all built-in Godot node types):

```
Control (root, full rect anchor)
└── VBox (VBoxContainer)
    ├── StatsRow (HBoxContainer)
    │   ├── TimeLabel (Label)
    │   ├── CashLabel (Label)
    │   └── VibeLabel (Label)
    └── SceneCard (VBoxContainer, or PanelContainer > VBoxContainer for a card look)
        ├── LocationLabel (Label)
        ├── StoryText (RichTextLabel, enable "Fit Content" / autowrap)
        ├── SpeakerLabel (Label)
        ├── SpeakerLine (Label)
        └── ChoicesBox (VBoxContainer)  ← buttons are added here at runtime
```

Attach `scripts/Main.gd` to the root `Control` node. The `@onready` paths in that
script assume exactly this structure — adjust them if you rename or nest nodes
differently.

Set `Main.tscn` as the run scene (already configured in `project.godot` via
`run/main_scene`).

## 3. Autoloads
Already registered in `project.godot`:
- `GameState` → `autoload/GameState.gd` (time / cash / vibe)
- `DialogueManager` → `scripts/DialogueManager.gd` (scene data + branching)

You shouldn't need to register these manually — Godot reads them from
`project.godot` automatically.

## 4. Run it
Press Play. You should see the opening scene with three choice buttons; picking
one updates the stats and advances the story through to one of four endings.

This version is **fully self-contained in GDScript** — no external addons
required. It's a direct port of the same branching logic as the `.ink` script
and the Rust CLI version, just running natively in Godot.

---

## Optional next step: swapping in real Ink authoring

The included `danfo_chronicles.ink` file (in the sibling `narrative/` folder if
you copy it in) is the same story written in Ink's own scripting language,
which is much nicer for a writer to extend — no code, just text and `+`
choices.

To actually run `.ink` files inside Godot, you'd install the **InkGD** addon
(a Godot plugin that runs compiled Ink JSON through Godot). I have **not**
verified InkGD's current API here — addon APIs change between versions — so
treat this as a starting point to check against that addon's own docs once
installed, not copy-paste-ready code:

1. Install InkGD via the Godot AssetLib panel (search "Ink").
2. Compile `danfo_chronicles.ink` to JSON with `inklecate` (Ink's own compiler,
   ships with the Inky editor — https://github.com/inkle/inky).
3. Replace `DialogueManager.gd`'s hand-written `scenes` dictionary with calls
   into InkGD's story-runner API (typically something like loading the
   compiled JSON into an `InkStory` resource, then calling a `continue_story()`
   / reading `current_choices` style API — check InkGD's README for the exact
   method names in the version you install).
4. Keep `GameState.gd` as-is — you'd still want Godot-side variables for
   stats, either mirrored from Ink's own `VAR` state or driving it directly.

This buys you: non-programmers can extend the story by editing the `.ink` file
alone (add the hawker scene, a danfo breakdown, a whole campus-life story)
without touching GDScript at all.

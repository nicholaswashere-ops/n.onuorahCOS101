extends Node
## Scene/dialogue data + branching logic, self-contained in GDScript.
## No external addon required — this is the version project.godot actually runs.
## See narrative/README_ink_integration.md for how to swap this out for the
## InkGD-driven version once you've installed that addon and want richer authoring.

var current_scene_id: String = "start"

var scenes: Dictionary = {
	"start": {
		"loc": "OJOTA BUS STOP — 9:14am",
		"text": "Your sister's wedding starts by 11am for Lekki. Traffic don already tie for Third Mainland. A conductor dey shout \"Lekki-Ajah, one chance!\" from inside a rickety yellow danfo, while an okada man dey signal you from the other side.",
		"speaker": "Conductor",
		"line": "\"Enter now now, we dey commot!\"",
		"choices": [
			{"label": "Jump inside the danfo", "tag": "Cheaper, but slow — Third Mainland go choke", "next": "danfo_ride", "cash": -300, "time": -25, "vibe": 0},
			{"label": "Take the okada instead", "tag": "Faster, riskier, costs more", "next": "okada_ride", "cash": -800, "time": -10, "vibe": 0},
			{"label": "Wait and check your phone for a Bolt", "tag": "Safer, but surge pricing dey dis hour", "next": "bolt_check", "cash": 0, "time": -8, "vibe": 0},
		]
	},
	"danfo_ride": {
		"loc": "INSIDE THE DANFO — Third Mainland Bridge",
		"text": "The bus dey packed tight, and one aunty beside you don already start to complain about \"this country.\" Conductor dey hang for door, collecting fare with speed wey no be here. Bridge dey slow-slow crawl.",
		"speaker": "Aunty beside you",
		"line": "\"My brother, na so dis country be. Endure am.\"",
		"choices": [
			{"label": "Strike up conversation to pass time", "tag": "Small vibe boost", "next": "conductor_trouble", "cash": 0, "time": -6, "vibe": 8},
			{"label": "Put on headphones and zone out", "tag": "Ignore the go-slow stress", "next": "conductor_trouble", "cash": 0, "time": -6, "vibe": 4},
		]
	},
	"okada_ride": {
		"loc": "OKADA — weaving through Ozumba Mbadiwe",
		"text": "Wind dey slap your face as the okada man dodge between danfos and potholes like professional. You dey enjoy the speed small, until una see a police checkpoint ahead — the rider slow down and start counting change quietly.",
		"speaker": "Okada man",
		"line": "\"Oga, no worry, na small something we go give them.\"",
		"choices": [
			{"label": "Let him handle the checkpoint his way", "tag": "Costs a little, keeps moving", "next": "lekki_arrival", "cash": -500, "time": -8, "vibe": 0},
			{"label": "Insist on stopping properly and asking questions", "tag": "Slower, but you keep your money", "next": "checkpoint_delay", "cash": 0, "time": -15, "vibe": 0},
		]
	},
	"bolt_check": {
		"loc": "OJOTA BUS STOP — checking your phone",
		"text": "Bolt app dey show ₦4,200 for a ride to Lekki because of surge. Your data dey also finish small small as the app struggle to load. A danfo conductor still dey shout beside you, and an okada man just pull up asking if you need a ride.",
		"speaker": "Okada man",
		"line": "\"Oga you go still dey here when I don reach Lekki o.\"",
		"choices": [
			{"label": "Book the Bolt anyway", "tag": "Expensive but stress-free", "next": "lekki_arrival", "cash": -4200, "time": -15, "vibe": 0},
			{"label": "Forget it, jump on the okada", "tag": "Cheaper and faster", "next": "okada_ride", "cash": 0, "time": -4, "vibe": 0},
		]
	},
	"conductor_trouble": {
		"loc": "THIRD MAINLAND BRIDGE — still crawling",
		"text": "The conductor dey argue with a passenger about change — \"I don give you your balance na, abeg no dull me today.\" The whole bus dey drag am into the matter. Meanwhile, traffic just start moving small.",
		"speaker": "You (thinking)",
		"line": "\"If I miss this wedding because of ₦50 change wahala, e go pain me.\"",
		"choices": [
			{"label": "Stay quiet, focus on the road ahead", "tag": "Keep your calm", "next": "lekki_arrival", "cash": 0, "time": -10, "vibe": 5},
			{"label": "Help settle the change dispute yourself", "tag": "Small cash loss, but bus moves faster", "next": "lekki_arrival", "cash": -100, "time": -5, "vibe": 10},
		]
	},
	"checkpoint_delay": {
		"loc": "POLICE CHECKPOINT — Ozumba Mbadiwe",
		"text": "An officer leans in, checks your bag lazily, asks where you dey rush to. You explain say na wedding. He waves you through with a warning, but you don already lose precious minutes.",
		"speaker": "Officer",
		"line": "\"Wedding? Ehen, go well. Tell them make dem no forget rice o.\"",
		"choices": [
			{"label": "Continue to Lekki", "tag": "", "next": "lekki_arrival", "cash": 0, "time": -5, "vibe": 0},
		]
	},
	"lekki_arrival": {
		"loc": "LEKKI — approaching the wedding venue",
		"text": "You can hear highlife music and generator hum from a few streets away. Your outfit dey slightly rumpled, your phone dey buzz with messages from your mother, but you don almost reach.",
		"speaker": "Mother (text message)",
		"line": "\"Where are you?? They are about to start the dance entry o!!\"",
		"choices": [
			{"label": "See how it plays out", "tag": "", "next": "ending", "cash": 0, "time": 0, "vibe": 0},
		]
	},
}

func get_current_scene() -> Dictionary:
	return scenes.get(current_scene_id, {})

func choose(choice_index: int) -> void:
	var scene: Dictionary = get_current_scene()
	var choices: Array = scene.get("choices", [])
	if choice_index < 0 or choice_index >= choices.size():
		return
	var c: Dictionary = choices[choice_index]
	GameState.apply_delta(c.get("time", 0), c.get("cash", 0), c.get("vibe", 0))

	if GameState.is_time_up() and c["next"] != "ending":
		current_scene_id = "ending"
	else:
		current_scene_id = c["next"]

func reset() -> void:
	current_scene_id = "start"
	GameState.reset()

func get_ending() -> Dictionary:
	if GameState.is_time_up():
		return {
			"title": "YOU MISSED THE ENTRY DANCE",
			"text": "Time finish before you reach. You arrive just as they're cutting the cake — your mother is not amused, but at least you made it before the food finished."
		}
	elif GameState.vibe >= 60:
		return {
			"title": "SMOOTH LANDING",
			"text": "You walk in cool, calm, and right on time — dancing your way straight into the reception like Lagos traffic never stood a chance."
		}
	elif GameState.cash <= 500:
		return {
			"title": "BROKE BUT BLESSED",
			"text": "You made it on time, but your wallet is crying. Worth it though — you didn't miss your sister's big entrance."
		}
	else:
		return {
			"title": "YOU MADE IT — BARELY",
			"text": "Sweaty, slightly late, but present. Your sister spots you from across the room and just shakes her head, smiling."
		}

extends Control
## Attach this to the root Control node of Main.tscn.
## Expects the node tree described in README.md — build it in the editor,
## then set the @onready paths below to match your actual scene tree.

@onready var time_label: Label = $VBox/StatsRow/TimeLabel
@onready var cash_label: Label = $VBox/StatsRow/CashLabel
@onready var vibe_label: Label = $VBox/StatsRow/VibeLabel
@onready var location_label: Label = $VBox/SceneCard/LocationLabel
@onready var story_text: RichTextLabel = $VBox/SceneCard/StoryText
@onready var speaker_label: Label = $VBox/SceneCard/SpeakerLabel
@onready var speaker_line: Label = $VBox/SceneCard/SpeakerLine
@onready var choices_box: VBoxContainer = $VBox/SceneCard/ChoicesBox

func _ready() -> void:
	GameState.stats_changed.connect(_update_stats)
	DialogueManager.reset()
	_update_stats()
	_render_scene()

func _update_stats() -> void:
	time_label.text = "Time: %d min" % GameState.time_left
	cash_label.text = "Cash: ₦%d" % GameState.cash
	vibe_label.text = "Vibe: %s" % GameState.vibe_label()

func _render_scene() -> void:
	for child in choices_box.get_children():
		child.queue_free()

	if DialogueManager.current_scene_id == "ending":
		_render_ending()
		return

	var scene: Dictionary = DialogueManager.get_current_scene()
	location_label.text = scene.get("loc", "")
	story_text.text = scene.get("text", "")

	var speaker: String = scene.get("speaker", "")
	if speaker != "":
		speaker_label.text = speaker
		speaker_line.text = scene.get("line", "")
		speaker_label.visible = true
		speaker_line.visible = true
	else:
		speaker_label.visible = false
		speaker_line.visible = false

	var choices: Array = scene.get("choices", [])
	for i in range(choices.size()):
		var c: Dictionary = choices[i]
		var btn := Button.new()
		var label_text: String = c["label"]
		if c.get("tag", "") != "":
			label_text += "\n[%s]" % c["tag"]
		btn.text = label_text
		btn.pressed.connect(_on_choice_pressed.bind(i))
		choices_box.add_child(btn)

func _on_choice_pressed(index: int) -> void:
	DialogueManager.choose(index)
	_render_scene()

func _render_ending() -> void:
	var ending: Dictionary = DialogueManager.get_ending()
	location_label.text = ""
	story_text.text = "[b]%s[/b]\n\n%s" % [ending["title"], ending["text"]]
	speaker_label.visible = false
	speaker_line.visible = false

	var btn := Button.new()
	btn.text = "Try again"
	btn.pressed.connect(_on_restart_pressed)
	choices_box.add_child(btn)

func _on_restart_pressed() -> void:
	DialogueManager.reset()
	_render_scene()

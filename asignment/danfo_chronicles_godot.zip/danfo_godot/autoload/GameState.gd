extends Node
## Global game state — time, cash, vibe.
## Registered as an autoload singleton ("GameState") in project.godot,
## so any script can read/write it as GameState.time_left, etc.

signal stats_changed

var time_left: int = 90
var cash: int = 2500
var vibe: int = 60

func reset() -> void:
	time_left = 90
	cash = 2500
	vibe = 60
	stats_changed.emit()

func apply_delta(time_delta: int, cash_delta: int, vibe_delta: int) -> void:
	time_left = max(0, time_left + time_delta)
	cash = max(0, cash + cash_delta)
	vibe = clamp(vibe + vibe_delta, 0, 100)
	stats_changed.emit()

func vibe_label() -> String:
	if vibe >= 70:
		return "Unbothered"
	elif vibe >= 40:
		return "Calm"
	elif vibe >= 20:
		return "Vexed"
	else:
		return "Don Vex Finish"

func is_time_up() -> bool:
	return time_left <= 0
